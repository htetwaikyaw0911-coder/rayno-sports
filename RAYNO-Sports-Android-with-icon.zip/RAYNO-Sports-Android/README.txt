RAYNO Sports - Android project (icon added)

APK ထုတ်နည်း (လွယ်ဆုံး - GitHub Actions)
1. github.com မှာ repository အသစ်ဆောက်ပြီး ဒီ folder ထဲက ဖိုင်အားလုံး (.github folder အပါအဝင်) upload လုပ်ပါ။
2. Actions tab > "Build APK" > Run workflow
3. ပြီးရင် Artifacts ထဲက RAYNO-Sports-APK ကို download ဆွဲပြီး app-debug.apk ကို install လုပ်ပါ။

Android Studio နဲ့ဆိုရင် folder ကိုဖွင့် > Build > Build APK(s)

Links ပြင်ချင်ရင် app/src/main/assets/index.html (CFG block)
